module.exports = {
  theme: {
    extend: {
      fontFamily: {
        heading: ["Playfair Display", "serif"],
        body: ["Nunito", "sans-serif"],
      },
    },
  },
};
